<?php
if (!defined('ABSPATH')) { exit; }

class ABC_CSV_Manager {

    // Batch importer settings (shared-hosting safe)
    // Default batch settings (fast but still shared-hosting safe).
    // You can override via filters: abcps_csv_batch_size and abcps_csv_batch_seconds.
    const BATCH_SIZE    = 1000; // rows per request
    const BATCH_SECONDS = 8.0;  // soft time budget per request

    public function __construct() {
        add_action('admin_menu', [$this, 'register_csv_page']);
        add_action('admin_post_abc_import_csv', [$this, 'handle_csv_import']);
        add_action('admin_post_abc_delete_all_csv', [$this, 'handle_delete_all_csv']);
        add_action('admin_notices', [$this, 'render_admin_notices']);

        // Batch import endpoint (prevents 503 on very large CSVs)
        add_action('wp_ajax_abc_import_csv_batch', [$this, 'ajax_import_csv_batch']);
    }

    public function register_csv_page() {
        add_submenu_page(
            'edit.php?post_type=abc_estimate',
            'Import / Data Tools',
            'Import / Data Tools',
            'manage_options',
            'abc-import',
            [$this, 'render_csv_page']
        );
    }

    public function render_csv_page() {
        $import_token = isset($_GET['import_token']) ? sanitize_text_field(wp_unslash($_GET['import_token'])) : '';
        $batch_nonce  = wp_create_nonce('abc_import_batch_nonce');
        ?>
        <div class="wrap">
            <h1>Import Log Book CSV</h1>

            <div class="notice notice-info inline">
                <p><strong>Tip for large files:</strong> If your CSV has more than ~5,000 rows, split it into smaller parts (e.g., “Part 1.csv”, “Part 2.csv”) and import them one by one. Some shared hosts still time out very large imports.</p>
            </div>

            <?php if ($import_token) : ?>
                <div class="card" style="max-width: 900px; padding: 16px 20px; margin-top: 12px;">
                    <h2 style="margin-top:0;">Import in progress…</h2>
                    <p id="abcps-import-status">Starting…</p>
                    <div style="height:12px; background:#e5e5e5; border-radius:999px; overflow:hidden;">
                        <div id="abcps-import-bar" style="height:12px; width:0%; background:#2271b1;"></div>
                    </div>
                    <p style="margin-top:10px; color:#666;">You can leave this tab open. The import runs in small batches to prevent server timeouts.</p>
                </div>
                <script>
                (function(){
                    var token = <?php echo wp_json_encode($import_token); ?>;
                    var nonce = <?php echo wp_json_encode($batch_nonce); ?>;
                    var ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;

                    function post(data){
                        return fetch(ajaxUrl, {
                            method: 'POST',
                            headers: {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
                            body: new URLSearchParams(data).toString(),
                            credentials: 'same-origin'
                        }).then(function(r){ return r.json(); });
                    }

                    function tick(){
                        post({action:'abc_import_csv_batch', nonce: nonce, token: token}).then(function(res){
                            if(!res || !res.success){
                                document.getElementById('abcps-import-status').textContent = 'Import error. Please refresh and try again.';
                                return;
                            }
                            var d = res.data || {};
                            var pct = d.percent || 0;
                            document.getElementById('abcps-import-bar').style.width = pct + '%';
                            document.getElementById('abcps-import-status').textContent = d.message || ('Imported ' + (d.imported||0) + ' so far…');

                            if(d.done){
                                var url = new URL(window.location.href);
                                url.searchParams.delete('import_token');
                                url.searchParams.set('imported', String(d.imported||0));
                                window.location.href = url.toString();
                                return;
                            }
                            setTimeout(tick, 350);
                        }).catch(function(){
                            document.getElementById('abcps-import-status').textContent = 'Import error. Please refresh and try again.';
                        });
                    }

                    setTimeout(tick, 200);
                })();
                </script>
            <?php endif; ?>

            <div class="card" style="max-width: 900px; padding: 16px 20px;">
                <h2 style="margin-top:0;">Accepted CSV formats</h2>
                <p><strong>A) Legacy Physical Log Book export</strong> (Detected in your file)</p>
                <ul style="margin-left: 18px; list-style: disc;">
                    <li>Requires headers: <code>Invoice No</code>, <code>Company</code>, <code>Item</code>, <code>Quantity</code>, <code>Amount</code>, <code>Date</code></li>
                </ul>

                <p><strong>B) Simple format</strong> (3 columns)</p>
                <ul style="margin-left: 18px; list-style: disc;">
                    <li><code>Title, Invoice, Due Date</code></li>
                </ul>
            </div>

            <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top: 16px;">
                <input type="hidden" name="action" value="abc_import_csv">
                <?php wp_nonce_field('abc_import_csv', 'abc_import_nonce'); ?>
                <input type="file" name="abc_csv_file" accept=".csv" required>
                <button type="submit" class="button button-primary" style="margin-left: 8px;">Import CSV</button>
            </form>

            <div style="margin-top: 30px; border-top:1px solid #ddd; padding-top:20px;">
                <h3>Danger Zone</h3>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('WARNING: This will delete ALL entries that were previously imported via CSV. This process may take a minute. Are you sure?');">
                    <input type="hidden" name="action" value="abc_delete_all_csv">
                    <?php wp_nonce_field('abc_delete_all_csv', 'abc_delete_all_nonce'); ?>
                    <button type="submit" class="button button-link-delete" style="color: #b32d2e; border: 1px solid #b32d2e; padding: 4px 10px; background: #fff;">Delete All Imported Entries</button>
                </form>
            </div>
        </div>
        <?php
    }

    // --- Helpers ---

    private function normalize_due_date_for_storage($raw) {
        $raw = trim((string)$raw);
        if ($raw === '') return '';
        // Try yyyy-mm-dd
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $raw, $m)) {
            $year = (int)$m[1];
            return ($year < 2026) ? '' : $raw;
        }
        // Try mm/dd/yyyy
        if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $raw, $m)) {
            $month = str_pad($m[1], 2, '0', STR_PAD_LEFT);
            $day   = str_pad($m[2], 2, '0', STR_PAD_LEFT);
            $year  = (int)$m[3];
            if ($year < 2026) return '';
            return sprintf('%04d-%02d-%02d', $year, (int)$month, (int)$day);
        }
        return $raw;
    }

    private function parse_money($raw) {
        $raw = trim((string)$raw);
        if ($raw === '') return 0.0;
        $raw = str_replace([',', '$'], '', $raw);
        if (!is_numeric($raw)) return 0.0;
        return (float)$raw;
    }

    private function payment_status_from_columns($paid_cell, $amount_cell) {
        $paid_cell = trim((string)$paid_cell);
        if ($paid_cell === '') return 'unpaid';
        if (stripos($paid_cell, 'paid') !== false) return 'paid';
        $paid = $this->parse_money($paid_cell);
        $amount = $this->parse_money($amount_cell);
        if ($paid <= 0) return 'paid'; // Text or check mark
        if ($amount > 0 && $paid + 0.00001 < $amount) return 'deposit';
        return 'paid';
    }

    private function build_header_map($header_row) {
        $map = [];
        foreach ($header_row as $idx => $h) {
            $key = strtolower(trim((string)$h));
            $key = preg_replace('/\s+/', ' ', $key);
            if ($key !== '') {
                $map[$key] = $idx;
            }
        }
        return $map;
    }

    private function idx($map, $possible_keys) {
        foreach ($possible_keys as $k) {
            $k = strtolower(trim($k));
            if (isset($map[$k])) return $map[$k];
        }
        return null;
    }

    /**
     * FAST INSERT:
     * Creates the abc_estimate post and all meta using direct SQL.
     * This is dramatically faster than wp_insert_post + many update_post_meta calls.
     *
     * Note: This intentionally bypasses WP hooks/Trash for performance on large imports.
     */
    private function fast_insert_estimate($title, $excerpt, array $meta) {
        global $wpdb;

        $now     = current_time('mysql');
        $now_gmt = current_time('mysql', true);
        $author  = get_current_user_id();
        if (!$author) { $author = 1; }

        $post_name = sanitize_title($title);

        $post_row = [
            'post_author'           => $author,
            'post_date'             => $now,
            'post_date_gmt'         => $now_gmt,
            'post_content'          => '',
            'post_title'            => $title,
            'post_excerpt'          => $excerpt,
            'post_status'           => 'publish',
            'comment_status'        => 'closed',
            'ping_status'           => 'closed',
            'post_password'         => '',
            'post_name'             => $post_name,
            'to_ping'               => '',
            'pinged'                => '',
            'post_modified'         => $now,
            'post_modified_gmt'     => $now_gmt,
            'post_content_filtered' => '',
            'post_parent'           => 0,
            'guid'                  => '',
            'menu_order'            => 0,
            'post_type'             => 'abc_estimate',
            'post_mime_type'        => '',
            'comment_count'         => 0,
        ];

        $inserted = $wpdb->insert(
            $wpdb->posts,
            $post_row,
            [
                '%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%d','%s','%s','%d'
            ]
        );

        if (!$inserted) {
            return 0;
        }

        $post_id = (int) $wpdb->insert_id;
        if ($post_id <= 0) {
            return 0;
        }

        if (!empty($meta)) {
            $values_sql = [];
            $values     = [];

            foreach ($meta as $k => $v) {
                $values_sql[] = '(%d,%s,%s)';
                $values[] = $post_id;
                $values[] = (string) $k;
                $values[] = maybe_serialize($v);
            }

            $sql = "INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES " . implode(',', $values_sql);
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $wpdb->query($wpdb->prepare($sql, $values));
        }

        return $post_id;
    }

    // --- Main Handlers ---

    public function handle_csv_import() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('abc_import_csv', 'abc_import_nonce');

        if (empty($_FILES['abc_csv_file']['tmp_name'])) wp_die('No file.');

        // Start a batch import session instead of processing everything in one request.
        // This avoids 503/timeouts on shared hosting for large files.
        @set_time_limit(0);
        @ignore_user_abort(true);
        @ini_set('memory_limit', '1024M');

        $uploads = wp_upload_dir();
        $dir = trailingslashit($uploads['basedir']) . 'abcps-imports/';
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }

        $token = wp_generate_uuid4();
        $dest  = $dir . 'import-' . $token . '.csv';

        // Move uploaded CSV into uploads so AJAX batch calls can read it.
        if (!@move_uploaded_file($_FILES['abc_csv_file']['tmp_name'], $dest)) {
            wp_die('Upload failed. Please try again.');
        }

        // Inspect first row to determine format and build header map.
        $handle = fopen($dest, 'r');
        if (!$handle) wp_die('Error opening uploaded file.');
        $first_row = fgetcsv($handle);
        fclose($handle);
        if ($first_row === false) {
            wp_die('CSV appears to be empty.');
        }

        $header_map = $this->build_header_map($first_row);
        $is_legacy = ($this->idx($header_map, ['invoice no', 'invoice #', 'invoice']) !== null) &&
                     ($this->idx($header_map, ['company', 'client']) !== null || $this->idx($header_map, ['item']) !== null);

        $invoice_cache = $dir . 'invoices-' . $token . '.ser';

        $state = [
            'file'          => $dest,
            'invoice_cache' => $invoice_cache,
            'is_legacy'     => $is_legacy ? 1 : 0,
            'header_map'    => $header_map,
            // CSV line offset (0-based). If legacy, line 0 is header, so start at 1.
            'line'          => $is_legacy ? 1 : 0,
            'imported'      => 0,
            'errors'        => [],
            'started'       => time(),
        ];

        set_transient('abcps_import_' . $token, $state, DAY_IN_SECONDS);

        wp_safe_redirect(admin_url('edit.php?post_type=abc_estimate&page=abc-import&import_token=' . rawurlencode($token)));
        exit;
    }

    /**
     * AJAX batch import runner.
     * Called repeatedly by the Import / Data Tools page when an import_token is present.
     */
    public function ajax_import_csv_batch() {
        check_ajax_referer('abc_import_batch_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }

        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
        if ($token === '') {
            wp_send_json_error(['message' => 'Missing token']);
        }

        $state = get_transient('abcps_import_' . $token);
        if (!$state || empty($state['file']) || !file_exists($state['file'])) {
            wp_send_json_error(['message' => 'Import session not found or file missing.']);
        }

        @set_time_limit(0);
        @ignore_user_abort(true);

        global $wpdb;

        // Build or load invoice cache for fast duplicate checks.
        $invoice_cache = $state['invoice_cache'];
        if (!file_exists($invoice_cache)) {
            $existing_invoices = $wpdb->get_col("SELECT meta_value FROM $wpdb->postmeta WHERE meta_key = 'abc_invoice_number'");
            $existing_map = array_fill_keys(array_filter(array_map('strval', $existing_invoices)), true);
            file_put_contents($invoice_cache, serialize($existing_map));
        }

        $existing_map = @unserialize(@file_get_contents($invoice_cache));
        if (!is_array($existing_map)) $existing_map = [];

        $is_legacy  = !empty($state['is_legacy']);
        $header_map = is_array($state['header_map']) ? $state['header_map'] : [];
        $line       = max(0, intval($state['line']));

        $batch_size = (int) apply_filters('abcps_csv_batch_size', self::BATCH_SIZE);
        if ($batch_size < 50) { $batch_size = 50; }

        $time_budget = (float) apply_filters('abcps_csv_batch_seconds', self::BATCH_SECONDS);
        if ($time_budget < 2) { $time_budget = 2; }

        $t0 = microtime(true);
        $processed = 0;
        $imported  = 0;

        $csv = new SplFileObject($state['file'], 'r');
        $csv->setFlags(SplFileObject::READ_CSV | SplFileObject::SKIP_EMPTY);
        $csv->seek($line);

        while ($csv->valid()) {
            if ($processed >= $batch_size) break;
            if ((microtime(true) - $t0) >= $time_budget) break;

            $row = $csv->current();
            $csv->next();
            $processed++;

            if (!is_array($row) || count($row) === 0) continue;

            // Skip blank rows
            // Skip blank rows
            $all_blank = true;
            foreach ($row as $cell) {
                if (trim((string)$cell) !== '') { $all_blank = false; break; }
            }
            if ($all_blank) {
                continue;
            }

            $invoice = '';
            $title = '';
            $client = '';
            $desc = '';
            $due_date = '';
            $order_date = '';
            $qty = '';
            $total = '';
            $paid_status = 'unpaid';
            $is_rush = '0';

            if ($is_legacy) {
                $i_inv = $this->idx($header_map, ['invoice no', 'invoice #', 'invoice']);
                $invoice = ($i_inv !== null && isset($row[$i_inv])) ? trim((string)$row[$i_inv]) : '';
                if ($invoice === '') continue;
                if (isset($existing_map[$invoice])) continue;
                if (!preg_match('/^\d{4}-\d{2}$/', $invoice)) continue;

                $i_co = $this->idx($header_map, ['company', 'client', 'customer']);
                $client = ($i_co !== null && isset($row[$i_co])) ? trim((string)$row[$i_co]) : 'Walk-in';

                $i_item = $this->idx($header_map, ['item', 'job', 'description']);
                $item = ($i_item !== null && isset($row[$i_item])) ? trim((string)$row[$i_item]) : '';

                $i_qty = $this->idx($header_map, ['quantity', 'qty']);
                $qty = ($i_qty !== null && isset($row[$i_qty])) ? trim((string)$row[$i_qty]) : '';

                $i_notes = $this->idx($header_map, ['notes', 'note']);
                $notes = ($i_notes !== null && isset($row[$i_notes])) ? trim((string)$row[$i_notes]) : '';

                $i_amt = $this->idx($header_map, ['amount', 'total', 'total ($)']);
                $total = ($i_amt !== null && isset($row[$i_amt])) ? trim((string)$row[$i_amt]) : '';

                // Paid column mapping
                $i_paid = $this->idx($header_map, ['paid', 'paid from', 'paid-from', 'paid-from-column']);
                $paid_raw = ($i_paid !== null && isset($row[$i_paid])) ? trim((string)$row[$i_paid]) : '';
                $paid_status = $this->payment_status_from_columns($paid_raw, $total);

                // Optional rush marker ("hot") — does NOT affect paid status
                $i_hot = $this->idx($header_map, ['hot', 'rush']);
                $hot_raw = ($i_hot !== null && isset($row[$i_hot])) ? trim((string)$row[$i_hot]) : '';
                if ($hot_raw !== '' && $hot_raw !== '0') {
                    $is_rush = '1';
                }

                // Optional due date column (cleared if <2026)
                $i_due = $this->idx($header_map, ['due date', 'due']);
                $due_raw = ($i_due !== null && isset($row[$i_due])) ? trim((string)$row[$i_due]) : '';
                $due_date = $this->normalize_due_date_for_storage($due_raw);

                $i_date = $this->idx($header_map, ['date', 'date in']);
                $d_raw = ($i_date !== null && isset($row[$i_date])) ? trim((string)$row[$i_date]) : '';
                if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $d_raw, $m)) {
                    $order_date = sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[1], (int)$m[2]);
                }

                $desc_parts = [];
                if ($item) $desc_parts[] = $item;
                if ($qty)  $desc_parts[] = 'Qty: ' . $qty;
                if ($notes) $desc_parts[] = 'Notes: ' . $notes;
                $desc = implode("\n", $desc_parts);

                $title = $client . ' - ' . $invoice;

            } else {
                // Simple: Title, Invoice, Due
                if (count($row) < 2) continue;
                $title = sanitize_text_field($row[0]);
                $invoice = sanitize_text_field($row[1]);
                if ($invoice === '' || isset($existing_map[$invoice])) continue;
                if (!preg_match('/^\d{4}-\d{2}$/', $invoice)) continue;
                $due_raw = isset($row[2]) ? (string)$row[2] : '';
                $due_date = $this->normalize_due_date_for_storage($due_raw);
            }

            // FAST INSERT (1 post insert + 1 meta multi-insert)
            $index = 'Inv:' . $invoice . ' | ' . $client . ' | ' . $desc;

            $post_id = $this->fast_insert_estimate($title, $index, [
                'abc_invoice_number' => $invoice,
                'abc_client_name'    => $client,
                'abc_job_description'=> $desc,
                'abc_qty'            => $qty,
                'abc_order_total'    => $total,
                'abc_paid_status'    => $paid_status,
                'abc_order_date'     => $order_date,
                'abc_due_date'       => $due_date,
                'abc_is_rush'        => $is_rush,
                // Historical imports default to completed
                'abc_status'         => 'completed',
                'abc_is_imported'    => '1',
            ]);

            if (!$post_id) {
                continue;
            }

            $existing_map[$invoice] = true;
            $imported++;
        }

        // Advance pointer to next line
        $state['line'] = (int)$csv->key();
        $state['imported'] = (int)$state['imported'] + $imported;

        // Persist invoice cache and state
        file_put_contents($invoice_cache, serialize($existing_map));
        set_transient('abcps_import_' . $token, $state, DAY_IN_SECONDS);

        $done = !$csv->valid();
        if ($done) {
            // Cleanup
            delete_transient('abcps_import_' . $token);
            @unlink($state['file']);
            @unlink($invoice_cache);
        }

        wp_send_json_success([
            'processed' => $processed,
            'imported'  => $state['imported'],
            'line'      => $state['line'],
            'done'      => $done,
        ]);
    }


    public function handle_delete_all_csv() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('abc_delete_all_csv', 'abc_delete_all_nonce');

        // Some hosts ignore PHP time-limit overrides, but we try anyway.
        @set_time_limit(0);
        @ignore_user_abort(true);
        @ini_set('memory_limit', '2048M');

        global $wpdb;

        /**
         * FAST WIPE (SQL-based)
         *
         * WordPress's wp_delete_post() is extremely expensive for thousands of rows.
         * On many hosts it will time out no matter what we do in PHP.
         *
         * This approach deletes imported entries directly from the database.
         * It bypasses Trash and delete hooks (intentional), but it is reliable for 10k+ records.
         */

        // 1) Delete revisions/autosaves that belong to imported entries
        $wpdb->query(
            "DELETE pm FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE p.post_type = 'revision'
               AND p.post_parent IN (
                   SELECT post_id FROM {$wpdb->postmeta}
                   WHERE meta_key = 'abc_is_imported' AND meta_value = '1'
               )"
        );
        $wpdb->query(
            "DELETE tr FROM {$wpdb->term_relationships} tr
             INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
             WHERE p.post_type = 'revision'
               AND p.post_parent IN (
                   SELECT post_id FROM {$wpdb->postmeta}
                   WHERE meta_key = 'abc_is_imported' AND meta_value = '1'
               )"
        );
        $wpdb->query(
            "DELETE p FROM {$wpdb->posts} p
             WHERE p.post_type = 'revision'
               AND p.post_parent IN (
                   SELECT post_id FROM {$wpdb->postmeta}
                   WHERE meta_key = 'abc_is_imported' AND meta_value = '1'
               )"
        );

        // 2) Delete term relationships for imported entries
        $wpdb->query(
            "DELETE tr FROM {$wpdb->term_relationships} tr
             INNER JOIN {$wpdb->postmeta} flag
                ON flag.post_id = tr.object_id
               AND flag.meta_key = 'abc_is_imported'
               AND flag.meta_value = '1'"
        );

        // 3) Delete the imported posts (CPT rows)
        $wpdb->query(
            "DELETE p FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} flag
                ON flag.post_id = p.ID
               AND flag.meta_key = 'abc_is_imported'
               AND flag.meta_value = '1'
             WHERE p.post_type = 'abc_estimate'"
        );

        // 4) Delete postmeta for imported posts (including the flag itself)
        $wpdb->query(
            "DELETE pm FROM {$wpdb->postmeta} pm
             INNER JOIN (
                 SELECT post_id FROM {$wpdb->postmeta}
                 WHERE meta_key = 'abc_is_imported' AND meta_value = '1'
             ) x ON x.post_id = pm.post_id"
        );

        wp_safe_redirect(admin_url('edit.php?post_type=abc_estimate&page=abc-import&deleted=1'));
        exit;
    }

    public function render_admin_notices() {
        if (isset($_GET['page']) && $_GET['page'] === 'abc-import') {
            if (isset($_GET['imported'])) {
                echo '<div class="notice notice-success"><p>Imported ' . intval($_GET['imported']) . ' items.</p></div>';
            }
            if (isset($_GET['deleted'])) {
                echo '<div class="notice notice-success"><p>Success: Deleted all imported entries.</p></div>';
            }
            $errors = get_transient('abc_csv_errors');
            if ($errors && is_array($errors) && count($errors) > 0) {
                echo '<div class="notice notice-warning" style="max-height: 200px; overflow-y:auto;"><p><strong>Import warnings:</strong></p><ul style="list-style:disc; margin-left:20px;">';
                foreach ($errors as $e) {
                    echo '<li>' . esc_html($e) . '</li>';
                }
                echo '</ul></div>';
                delete_transient('abc_csv_errors');
            }
        }
    }
}
