# PressDrop Bleed Fixer — Build EXE (Windows)

This project can be packaged into Windows executables using **PyInstaller**.

## Recommended build environment
- Windows 10/11
- **Python 3.12 x64** (recommended for easiest dependency installs)
  - Your workstation currently has Python 3.14, which can force pip to compile some packages from source.
  - Building with 3.12 avoids that pain.

## Build (GUI + CLI)
1. Open this folder in File Explorer.
2. Double‑click: **build_exe.bat**
3. When finished, you’ll find:
   - `build\dist\PressDropBleedFixer.exe`
   - `build\dist\PressDropBleedFixer_CLI.exe`

## Notes
- The GUI EXE is built with `console=False` (no terminal window).
  - If you want to see logs while testing, change `console=True` in `build\pressdrop_gui.spec`.
- The EXE bundles `presets\`, `indesign\`, and `examples\` so presets and the JSX are included.
- If you need an installer later, we can wrap the `dist\` output with Inno Setup or NSIS.

## Troubleshooting
### “py -3.12” not found
Install Python 3.12 and ensure the Python Launcher is installed, or edit `build_exe.bat` to point to your python.exe.

### Corporate PCs / blocked pip downloads
If pip can’t download packages, we can switch to an “offline wheels” build (I can prep a `wheels\` folder and install from it).
