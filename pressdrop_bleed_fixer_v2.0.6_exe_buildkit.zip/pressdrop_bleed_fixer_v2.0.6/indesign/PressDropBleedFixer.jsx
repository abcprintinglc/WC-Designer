/*
PressDrop Bleed Fixer (v2.0.6)

Reads a job JSON produced by the Python app and creates an INDD.

How to use:
1) In InDesign: Window > Utilities > Scripts
2) Put this JSX in your Scripts Panel folder
3) Double-click it
4) Select the job JSON file when prompted

Job schema (from Python):
- job.inputs[0].path
- job.inputs[0].pages (e.g., "1" or "1-4" or "all")
- job.inputs[0].pdf_box (auto/trim/crop/media)
- job.layout.trim {w,h,unit}
- job.layout.bleed {top,right,bottom,left,unit}
- job.layout.fit_mode
- job.layout.anchor
- job.output.dir
- job.output.basename

Notes:
- InDesign must have permission to read the input file and write to output folder.
*/

// --- JSON polyfill for older ExtendScript engines (some InDesign versions lack JSON) ---
if (typeof JSON === "undefined" || !JSON) {
  JSON = {};
}
if (!JSON.parse) {
  JSON.parse = function (s) {
    // NOTE: This is safe for our use because the job file is generated locally by PressDrop.
    return eval("(" + s + ")");
  };
}
if (!JSON.stringify) {
  JSON.stringify = function (obj) {
    // Minimal stringify (supports objects/arrays/strings/numbers/bools/null)
    function esc(str) {
      return str.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t");
    }
    if (obj === null) return "null";
    var t = typeof obj;
    if (t === "number" || t === "boolean") return String(obj);
    if (t === "string") return '"' + esc(obj) + '"';
    if (obj instanceof Array) {
      var a = [];
      for (var i = 0; i < obj.length; i++) a.push(JSON.stringify(obj[i]));
      return "[" + a.join(",") + "]";
    }
    if (t === "object") {
      var parts = [];
      for (var k in obj) {
        if (obj.hasOwnProperty && !obj.hasOwnProperty(k)) continue;
        parts.push('"' + esc(String(k)) + '":' + JSON.stringify(obj[k]));
      }
      return "{" + parts.join(",") + "}";
    }
    return "null";
  };
}
// --- end JSON polyfill ---



#target "InDesign"

function readTextFile(file) {
  file.encoding = "UTF-8";
  file.open("r");
  var text = file.read();
  file.close();
  return text;
}

function toPoints(value, unit) {
  unit = (unit || "in").toLowerCase();
  if (unit === "in" || unit === "inch" || unit === "inches") return value * 72.0;
  if (unit === "mm" || unit === "millimeter" || unit === "millimeters") return value * 72.0 / 25.4;
  if (unit === "pt" || unit === "pts" || unit === "point" || unit === "points") return value;
  throw new Error("Unsupported unit: " + unit);
}

function parsePages(spec, maxPages) {
  spec = (spec || "all").toLowerCase();
  if (spec === "all") {
    var all = [];
    for (var i = 1; i <= maxPages; i++) all.push(i);
    return all;
  }
  var parts = spec.split(",");
  var pages = [];
  for (var p = 0; p < parts.length; p++) {
    var t = parts[p].replace(/\s+/g, "");
    if (!t) continue;
    var dash = t.indexOf("-");
    if (dash >= 0) {
      var a = parseInt(t.substring(0, dash), 10);
      var b = parseInt(t.substring(dash + 1), 10);
      if (isNaN(a) || isNaN(b)) continue;
      for (var k = a; k <= b; k++) pages.push(k);
    } else {
      var n = parseInt(t, 10);
      if (!isNaN(n)) pages.push(n);
    }
  }
  // Clamp to valid range and de-dupe while preserving order.
  var out = [];
  var seen = {};
  for (var i2 = 0; i2 < pages.length; i2++) {
    var v = pages[i2];
    if (typeof v !== "number" || isNaN(v)) continue;
    if (v < 1) continue;
    if (maxPages && v > maxPages) continue;
    if (seen[v]) continue;
    seen[v] = true;
    out.push(v);
  }
  return out;
}

function getBleedBounds(pageBounds, bleedPts) {
  // pageBounds: [y1, x1, y2, x2]
  return [
    pageBounds[0] - bleedPts.top,
    pageBounds[1] - bleedPts.left,
    pageBounds[2] + bleedPts.bottom,
    pageBounds[3] + bleedPts.right
  ];
}

function applyFit(rect, mode) {
  // Basic fitting. After placing, call rect.fit(...)
  if (mode === "fill_bleed_proportional" || mode === "fill_trim_proportional") {
    rect.fit(FitOptions.FILL_PROPORTIONALLY);
    rect.fit(FitOptions.CENTER_CONTENT);
    return;
  }
  if (mode === "stretch_bleed" || mode === "stretch_trim") {
    rect.fit(FitOptions.CONTENT_TO_FRAME);
    return;
  }
  // default proportional contain
  rect.fit(FitOptions.PROPORTIONALLY);
  rect.fit(FitOptions.CENTER_CONTENT);
}

function main() {
  var jobFile = File.openDialog("Select a PressDrop job JSON (*.job.json)", "JSON:*.json");
  if (!jobFile) return;

  var job = JSON.parse(readTextFile(jobFile));

  if (!job.layout || !job.layout.trim || !job.layout.bleed) {
    throw new Error("Job JSON missing layout.trim or layout.bleed");
  }

  var unit = job.layout.trim.unit || "in";
  var trimW = toPoints(job.layout.trim.w, unit);
  var trimH = toPoints(job.layout.trim.h, unit);

  var bUnit = job.layout.bleed.unit || unit;
  var bleedPts = {
    top: toPoints(job.layout.bleed.top, bUnit),
    right: toPoints(job.layout.bleed.right, bUnit),
    bottom: toPoints(job.layout.bleed.bottom, bUnit),
    left: toPoints(job.layout.bleed.left, bUnit)
  };

  var fitMode = (job.layout.fit_mode || "fit_trim_proportional").toLowerCase();

  var outDir = Folder(job.output.dir);
  if (!outDir.exists) outDir.create();
  var outIndd = File(outDir.fsName + "/" + job.output.basename + ".indd");

  // Create doc
  var doc = app.documents.add();
  doc.documentPreferences.pageWidth = trimW;
  doc.documentPreferences.pageHeight = trimH;
  doc.documentPreferences.pagesPerDocument = 1;

  doc.documentPreferences.documentBleedTopOffset = bleedPts.top;
  doc.documentPreferences.documentBleedInsideOrLeftOffset = bleedPts.left;
  doc.documentPreferences.documentBleedBottomOffset = bleedPts.bottom;
  doc.documentPreferences.documentBleedOutsideOrRightOffset = bleedPts.right;

  // Input
  if (!job.inputs || job.inputs.length < 1) throw new Error("Job JSON missing inputs");
  var inputPath = job.inputs[0].path;
  var inputFile = File(inputPath);
  if (!inputFile.exists) throw new Error("Input not found: " + inputPath);

  var ext = inputFile.name.split(".").pop().toLowerCase();
  var pagesToPlace = [1];
  var maxPagesForPdf = 1;

  // Pages
  var pageSpec = job.inputs[0].pages || "1";
  if (ext === "pdf") {
    // Prefer page count computed by the Python app (job.inputs[0].page_count).
    var pageCount = job.inputs[0].page_count;
    var maxPages = (pageCount && pageCount > 0) ? pageCount : 1;
    maxPagesForPdf = maxPages;

    // If user asked for 'all' but we don't know count, ask once.
    if (String(pageSpec).toLowerCase() === "all" && maxPages === 1) {
      var resp = prompt("PDF page count is unknown for 'all'.\nEnter the last page number to import:", "1");
      var nmax = parseInt(resp, 10);
      if (!isNaN(nmax) && nmax > 0) maxPages = nmax;
    }

	  // Persist final maxPages value
	  maxPagesForPdf = maxPages;

    pagesToPlace = parsePages(pageSpec, maxPages);

    // Guard against accidental huge imports
    if (pagesToPlace.length > 500) {
      var ok = confirm("You are about to import " + pagesToPlace.length + " pages.\nContinue?");
      if (!ok) return;
    }
  }

  // Ensure pages exist
  for (var i = 2; i <= pagesToPlace.length; i++) {
    doc.pages.add(LocationOptions.AT_END);
  }

  for (var idx = 0; idx < pagesToPlace.length; idx++) {
    var page = doc.pages[idx];
    var pageBounds = page.bounds; // [y1,x1,y2,x2] == trim
    var targetBounds = pageBounds;

    if (fitMode.indexOf("bleed") >= 0) {
      targetBounds = getBleedBounds(pageBounds, bleedPts);
    }

    // Frame
    var frame = page.rectangles.add();
    frame.geometricBounds = targetBounds;

    // Place
    if (ext === "pdf") {
      var pno = pagesToPlace[idx];
      if (typeof pno !== "number" || isNaN(pno) || pno < 1) {
        throw new Error("Invalid PDF page number: " + pno);
      }
      if (maxPagesForPdf && pno > maxPagesForPdf) {
        throw new Error("PDF page out of range: " + pno + " (max " + maxPagesForPdf + ")");
      }
      app.pdfPlacePreferences.pageNumber = pno;
      // crop preference: keep default for now; advanced mapping can be added later
	    try {
	      frame.place(inputFile);
	    } catch (pe) {
	      var pm = (pe && pe.message) ? pe.message : String(pe);
	      throw new Error("Place failed for PDF page " + pno + ": " + pm);
	    }
    } else {
      frame.place(inputFile);
    }

    applyFit(frame, fitMode);
  }

  doc.save(outIndd);
  alert("Saved INDD: " + outIndd.fsName);
}

try {
  app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
  main();
} catch (e) {
  // Show a clear message but do not rethrow (rethrow can hide the real source line).
  // ExtendScript doesn't allow raw newlines inside string literals.
  // Use \n explicitly to avoid "Unterminated string constant" errors.
  var msg = (e && e.message) ? e.message : String(e);
  var line = (e && e.line) ? e.line : "?";
  var file = (e && e.fileName) ? e.fileName : "";
  var extra = "\nLine: " + line;
  if (file) extra += "\nFile: " + file;
  alert("PressDrop INDD script failed:\n" + msg + extra);
}
